# Clash Royale Hub (Android)

Projeto Android nativo em Kotlin + Jetpack Compose.

## Como abrir e gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `ClashRoyaleHub` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale Android SDK 35 e aceite as atualizações sugeridas.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## O que já está implementado
- Navegação inferior: Início, Cartas, Decks, Arenas e Dicas.
- Busca por nome, raridade e função na biblioteca inicial de cartas.
- Guias de decks com detalhes.
- Lista de arenas e dicas estratégicas.
- Favoritos durante a sessão atual.

## Importante
Esta é a primeira versão funcional do projeto, não um APK já compilado. O conteúdo de cartas/decks é inicial e demonstrativo; atualize-o conforme as mudanças oficiais do jogo. O app não é afiliado à Supercell e não usa imagens ou marcas oficiais além do nome do jogo em caráter informativo.
