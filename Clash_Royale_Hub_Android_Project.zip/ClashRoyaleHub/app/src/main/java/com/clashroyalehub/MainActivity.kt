package com.clashroyalehub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF173B75)
private val Blue = Color(0xFF2878D0)
private val Gold = Color(0xFFFFC94A)
private val Cream = Color(0xFFFFF8E8)
private val Ink = Color(0xFF17243A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClashHubApp() }
    }
}

data class GuideCard(val name: String, val rarity: String, val elixir: String, val role: String, val tip: String)
data class Deck(val name: String, val cards: String, val style: String, val tip: String)

private val cards = listOf(
    GuideCard("Cavaleiro", "Comum", "3", "Mini-tanque", "Use para segurar tropas terrestres e proteger unidades de suporte."),
    GuideCard("Arqueiras", "Comum", "3", "Suporte", "Separe as unidades quando precisar cobrir duas rotas."),
    GuideCard("Bola de Fogo", "Rara", "4", "Feitiço", "Tente atingir tropas de suporte e a torre no mesmo lançamento."),
    GuideCard("Gigante", "Rara", "5", "Condição de vitória", "Monte o ataque atrás dele e evite gastar todo o elixir de uma vez."),
    GuideCard("Mosqueteira", "Rara", "4", "Suporte antiaéreo", "Proteja-a de feitiços e use seu alcance para defender."),
    GuideCard("Mini P.E.K.K.A", "Rara", "4", "Dano alto", "Ótimo para punir tanques; acompanhe a defesa com cuidado."),
    GuideCard("Mega Cavaleiro", "Lendária", "7", "Defesa e pressão", "A entrada causa impacto, mas não o coloque sem calcular o elixir."),
    GuideCard("Princesa", "Lendária", "3", "Pressão de longe", "Use o alcance para forçar respostas e controlar a ponte.")
)

private val decks = listOf(
    Deck("Gigante + suporte", "Gigante • Mosqueteira • Mini P.E.K.K.A • Arqueiras • Cavaleiro • Bola de Fogo • Flechas • Exército de Esqueletos", "Contra-ataque", "Defenda primeiro e transforme tropas sobreviventes em um ataque atrás do Gigante."),
    Deck("Pressão com Mega Cavaleiro", "Mega Cavaleiro • Princesa • Morcegos • Mineiro • Gangue de Goblins • Zap • Veneno • Torre Inferno", "Pressão e punição", "Não desperdice o Mega Cavaleiro no ataque. Aproveite defesas eficientes para pressionar."),
    Deck("Ciclo leve", "Cavaleiro • Arqueiras • Esqueletos • Espírito de Gelo • Canhão • Bola de Fogo • Tronco • Corredor", "Ciclo rápido", "Gire cartas baratas, descubra a defesa adversária e ataque quando ela estiver fora de rotação.")
)

private val arenas = listOf(
    "Campo de Treinamento", "Estádio Goblin", "Fosso dos Ossos", "Parquinho da P.E.K.K.A",
    "Vale dos Feitiços", "Oficina do Construtor", "Arena Real", "Pico Congelado",
    "Arena da Selva", "Montanha do Porco", "Vale Elétrico", "Cidade Assombrada"
)

@Composable
fun ClashHubApp() {
    var page by remember { mutableStateOf("Início") }
    var query by remember { mutableStateOf("") }
    var selectedCard by remember { mutableStateOf<GuideCard?>(null) }
    var selectedDeck by remember { mutableStateOf<Deck?>(null) }
    var saved by remember { mutableStateOf(setOf<String>()) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Cream)) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 14.dp)) {
                    Text("👑 CLASH ROYALE HUB", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text("Seu guia de batalha", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Navy) {
                    val destinations = listOf("Início", "Cartas", "Decks", "Arenas", "Dicas")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Style, Icons.Default.Shield, Icons.Default.Castle, Icons.Default.Lightbulb)
                    destinations.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = page == label,
                            onClick = { page = label; selectedCard = null; selectedDeck = null },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                unselectedIconColor = Color.White, unselectedTextColor = Color.White.copy(alpha = .8f),
                                indicatorColor = Blue
                            )
                        )
                    }
                }
            }
        ) { padding ->
            if (selectedCard != null) {
                DetailScreen("🃏 ${selectedCard!!.name}", listOf(
                    "Raridade: ${selectedCard!!.rarity}",
                    "Custo: ${selectedCard!!.elixir} de elixir",
                    "Função: ${selectedCard!!.role}",
                    selectedCard!!.tip
                ), { selectedCard = null }, saved.contains(selectedCard!!.name)) {
                    saved = if (saved.contains(selectedCard!!.name)) saved - selectedCard!!.name else saved + selectedCard!!.name
                }
            } else if (selectedDeck != null) {
                DetailScreen("🛡️ ${selectedDeck!!.name}", listOf(
                    "Estilo: ${selectedDeck!!.style}",
                    "Cartas: ${selectedDeck!!.cards}",
                    "Como jogar: ${selectedDeck!!.tip}",
                    "Dica: teste o deck em partidas amigáveis antes de usar em uma sequência de troféus."
                ), { selectedDeck = null }, saved.contains(selectedDeck!!.name)) {
                    saved = if (saved.contains(selectedDeck!!.name)) saved - selectedDeck!!.name else saved + selectedDeck!!.name
                }
            } else {
                when (page) {
                    "Início" -> HomeScreen(padding, saved.size, { page = it })
                    "Cartas" -> CardsScreen(padding, query, { query = it }, { selectedCard = it })
                    "Decks" -> DecksScreen(padding, { selectedDeck = it })
                    "Arenas" -> ArenasScreen(padding)
                    "Dicas" -> TipsScreen(padding)
                    else -> HomeScreen(padding, saved.size, { page = it })
                }
            }
        }
    }
}

@Composable
fun Header(text: String) {
    Text(text, color = Navy, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
fun RoyaleCard(title: String, subtitle: String, emoji: String = "⚔️", onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 28.sp, modifier = Modifier.padding(end = 13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(subtitle, color = Color.DarkGray, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Blue)
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, savedCount: Int, go: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Blue), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("🏆 SUBA DE ARENA!", color = Gold, fontWeight = FontWeight.Black, fontSize = 22.sp)
                    Text("Aprenda a montar decks, defender melhor e escolher o momento certo de atacar.", color = Color.White, modifier = Modifier.padding(top = 7.dp))
                    Button(onClick = { go("Dicas") }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy), modifier = Modifier.padding(top = 12.dp)) {
                        Text("VER GUIAS", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Header("Explore o Hub")
            RoyaleCard("Biblioteca de cartas", "Funções, raridades e dicas de uso", "🃏") { go("Cartas") }
            RoyaleCard("Decks e combinações", "Ideias para diferentes estilos de jogo", "🛡️") { go("Decks") }
            RoyaleCard("Arenas", "Progressão e orientações", "🏟️") { go("Arenas") }
            RoyaleCard("Estratégias", "Elixir, defesa, rotação e ataques", "⚡") { go("Dicas") }
            Spacer(Modifier.height(8.dp))
            Text("⭐ Favoritos salvos: $savedCount", color = Navy, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("Conteúdo demonstrativo: balanceamento, cartas e arenas podem mudar com atualizações do jogo.", color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
fun CardsScreen(padding: PaddingValues, query: String, onQuery: (String) -> Unit, onSelect: (GuideCard) -> Unit) {
    val filtered = cards.filter { it.name.contains(query, true) || it.rarity.contains(query, true) || it.role.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Header("🃏 Biblioteca de cartas")
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar carta, raridade ou função...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        LazyColumn {
            items(filtered) { card ->
                RoyaleCard(card.name, "${card.rarity} • ${card.elixir} de elixir • ${card.role}", "🃏") { onSelect(card) }
            }
            if (filtered.isEmpty()) item { Text("Nenhuma carta encontrada.", modifier = Modifier.padding(18.dp)) }
        }
    }
}

@Composable
fun DecksScreen(padding: PaddingValues, onSelect: (Deck) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
        item { Spacer(Modifier.height(16.dp)); Header("🛡️ Guias de decks") }
        items(decks) { deck -> RoyaleCard(deck.name, deck.style, "⚔️") { onSelect(deck) } }
        item { Text("Os decks são sugestões educativas. Ajuste as cartas conforme seu nível e as cartas disponíveis.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 12.dp)) }
    }
}

@Composable
fun ArenasScreen(padding: PaddingValues) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
        item { Spacer(Modifier.height(16.dp)); Header("🏟️ Guia de arenas") }
        items(arenas) { index ->
            val number = arenas.indexOf(index) + 1
            RoyaleCard("Arena $number: $index", "Dica: melhore seu deck principal e aprenda as cartas que mais aparecem no seu caminho.", "🏆") { }
        }
    }
}

@Composable
fun TipsScreen(padding: PaddingValues) {
    val tips = listOf(
        "Controle do elixir" to "Evite gastar tudo de uma vez. Uma defesa barata pode criar vantagem para o próximo ataque.",
        "Defenda antes de atacar" to "Defenda com eficiência e aproveite as tropas que sobreviverem para formar um contra-ataque.",
        "Observe a rotação" to "Preste atenção nas cartas que o adversário acabou de usar. Isso ajuda a escolher a hora de pressionar.",
        "Não entregue feitiços" to "Procure atingir tropas e torre juntas quando fizer sentido, sem forçar um lançamento ruim.",
        "Divida a pressão" to "Quando o adversário investir muito em uma rota, considere pressionar a outra, desde que consiga defender.",
        "Aprenda com as derrotas" to "Depois da partida, identifique se o problema foi elixir, posicionamento, rotação ou escolha de cartas."
    )
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
        item { Spacer(Modifier.height(16.dp)); Header("⚡ Estratégias essenciais") }
        items(tips) { tip ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text(tip.first, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(tip.second, color = Ink, modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(title: String, lines: List<String>, back: () -> Unit, isSaved: Boolean, toggleSaved: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Cream).padding(18.dp)) {
        TextButton(onClick = back) { Icon(Icons.Default.ArrowBack, null); Text(" Voltar") }
        Spacer(Modifier.height(12.dp))
        Text(title, color = Navy, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(16.dp))
        lines.forEach { line ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text(line, color = Ink, modifier = Modifier.padding(15.dp), fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = toggleSaved, colors = ButtonDefaults.buttonColors(containerColor = if (isSaved) Navy else Blue)) {
            Icon(if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null)
            Text(if (isSaved) "  Remover dos favoritos" else "  Salvar nos favoritos")
        }
    }
}
